# HealthNjoro.xyz

Static GitHub Pages-ready health information website.

## Includes
- Responsive homepage
- 20 individual article pages
- Search and category filtering
- Dark mode
- WhatsApp floating button
- SEO title/description/canonical/OG tags
- Article structured data
- sitemap.xml
- robots.txt
- About, Contact and Privacy pages

## Important
Replace the WhatsApp placeholder `254700000000` with your real WhatsApp number before publishing. Review health content and add credible sources/medical review where appropriate.
